#!/bin/bash

log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') ${1}" >> cuckoo.log
}

cleanup() {
    log_message "Shutdown!"
    [ -p /tmp/run/cuckoo.pid ] && rm -f /tmp/run/cuckoo.pid
    exit 0
}

trap cleanup SIGTERM SIGINT

mkdir -p /tmp/run
[ -p /tmp/run/cuckoo.pid ] && rm -f /tmp/run/cuckoo.pid
mkfifo /tmp/run/cuckoo.pid

if [ ! -p /tmp/run/cuckoo.pid ]; then
    exit 1
fi

log_message "Startup!"

while true; do
    if read request < /tmp/run/cuckoo.pid; then
        if [[ "${request}" =~ ^([^[]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            CLIENT_PID="${BASH_REMATCH[2]}"
            N=$(( RANDOM % 9 + 2 ))
            echo "${N}" > /tmp/run/cuckoo.pid
            log_message "${NAME}[${CLIENT_PID}] ${N}"
        else
            echo "" > /tmp/run/cuckoo.pid
        fi
    fi
done

cleanup
