#!/bin/bash

SCRIPT_NAME=$(basename "$0")

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG_FILE="report_${SCRIPT_NAME%.sh}.log"
PID=$$

echo "$(date '+%Y-%m-%d %H:%M:%S') [${PID}] Скрипт запущен" >> "${LOG_FILE}"

REQUEST="${SCRIPT_NAME}[${PID}]: how much time do I have?"
echo "${REQUEST}" > /tmp/run/cuckoo.pid

read N < /tmp/run/cuckoo.pid

sleep "${N}"

echo "$(date '+%Y-%m-%d %H:%M:%S') [${PID}] Скрипт завершился, работал ${N} секунд" >> "${LOG_FILE}"
